"""
Models from
https://github.com/MadryLab/cifar10_challenge
"""
