"""
Plotting and visualization
"""
